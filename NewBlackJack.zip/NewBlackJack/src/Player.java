import java.util.ArrayList;

public class Player {
	/**
	 * adds card values to hand list
	 * @param cardVal
	 * @param Hand
	 * @return sum of hand
	 */
	
	public int sumHand(int cardVal, ArrayList<Integer> Hand) {
		Hand.add(cardVal);
		int sum = 0;
		for (int i: Hand) {
			sum += i;
		}
		return sum;
	}
	
	
	/**
	 * adds the int card value to players hand
	 * @param card value
	 * @param second card value
	 * @return sum of players hand
	 */
	
	public int sumFirstCards(int cardVal,int cardVal2) {
		ArrayList<Integer> cards = new ArrayList<Integer>();
		cards.add(cardVal);
		cards.add(cardVal2);
		int sum = 0;
		for (int i: cards) {
			sum += i;
		}
		return sum;		
	}
	/**
	 * takes in user input as a bet and subtracts it by current chips
	 * @param bet
	 * @param chips
	 * @return new balance of chips after bet has been placed
	 */
	public int placeBet(int bet, int chips) {
		int newBalance = chips - bet;
		return newBalance;
		
	
	}

}
