
public class Card {
	/**
	 * method that gets a number from the deck
	 * @param deck
	 * @return number from deck thats between 1 & 13
	 */
	int getNum(int [] deck) {
		int num = deck[(int)(Math.random()*13)];
		return num;
	}
	/**
	 * 
	 * @param num
	 * @return string of the cards name
	 */
	public String getString(int num) {
		String cardName = null;
		switch(num) {
		case 1:
			cardName = "Ace";
			break;
		case 2:
			cardName = "Two";
			break;
		case 3:
			cardName = "Three";
			break;
		case 4:
			cardName = "Four";
			break;
		case 5:
			cardName = "Five";
			break;
		case 6:
			cardName = "Six";
			break;
		case 7:
			cardName = "Seven";
			break;
		case 8:
			cardName = "Eight";
			break;
		case 9:
			cardName = "Nine";
			break;
		case 10:
			cardName = "Ten";
			break;
		case 11:
			cardName = "Jack";
			break;
		case 12:
			cardName =  "Queen";
			break;
		case 13:
			cardName = "King";
			break;
		}
		return cardName;
	}
	/**
	 * method that takes a cards name and gives it a numerical value
	 * face cards value = 10
	 * if the hands value is 10 then ace = 11 else ace = 1
	 * 
	 * @param cardName
	 * @return int value of card
	 */
	public int cardVal(String cardName, int sum) {
		int cardVal = 0; //init card value variable
		switch(cardName) {
		case "Ace":
			if (sum <= 10) {
				cardVal = 11;
			}
			else if (sum > 10) {
				cardVal = 1;
			}
			break;
		case "Two":
			cardVal = 2;
			break;
		case "Three":
			cardVal = 3;
			break;
		case "Four":
			cardVal = 4;
			break;
		case "Five":
			cardVal = 5;
			break;
		case "Six":
			cardVal = 6;
			break;
		case "Seven":
			cardVal = 7;
			break;
		case "Eight":
			cardVal = 8;
			break;
		case "Nine":
			cardVal = 9;
			break;
		case "Ten":
			cardVal = 10;
			break;
		case "Jack":
			cardVal = 10;
			break;
		case "Queen":
			cardVal = 10;
			break;
		case "King":
			cardVal = 10;
			break;
			
		}
		return cardVal;
		
	}

}
