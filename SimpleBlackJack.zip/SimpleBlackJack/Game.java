
import java.util.ArrayList;
import java.util.Scanner;
/**
 * 
 * @author shaynekanner
 *
 */

public class Game {
	public static void main(String [] args) {
		boolean betting = false;
		boolean playing = false;
		boolean hitting = false;
		boolean checking = false;
		Card myCard = new Card(); //create card object
		Deck myDeck = new Deck(); //create deck object
		Player me = new Player(); //create player object
		Dealer myDealer = new Dealer(); //create dealer object
		Scanner input = new Scanner(System.in);
		System.out.println("Would you like to play?(yes/no)");
		String play = input.nextLine();
		if (!play.equals("no")) {
			playing = true;
			
		}else {
			playing = false;
			System.out.println("fuck off loser, go fucking waste someone elses time");
		}
		while (playing) {
			int chips = me.placeBet(0,20000);		
			betting = true;
			while (betting) {
			int dealersHand = 0; //init dealer hand
			int playerHand = 0; //init player hand
			System.out.println("Balance:" + chips + " " +"place bet");
			int bet = input.nextInt();
			chips = me.placeBet(bet, chips); //places bet
			System.out.println("Chip Balance:"+ chips);
			/**
			 * init player hand and dealers hand
			 */
			ArrayList<Integer> Hand = new ArrayList<Integer>(); // creates an empty list for users hand
			ArrayList<Integer> dealerHand = new ArrayList<Integer>(); //creates an empty list for dealers hand
			
			/**
			 * first two  player cards
			 */
			//gets card from deck
			String card1 = myCard.getString(myDeck.deck[(int)(Math.random()*13)]); //string of first card
			String card2 = myCard.getString(myDeck.deck[(int)(Math.random()*13)]); //string of second card
			/**
			 * first two dealers card
			 * second card stored under hidden, gets revealed later 
			 */
			String dealersCard1 = myCard.getString(myDeck.deck[(int)(Math.random()*13)]); //string of dealers first card
			String hiddenCard = myCard.getString(myDeck.deck[(int)(Math.random()*13)]); // dealers hidden card
			/**
			 * convert string of card into numerical value
			 */
			int first = myCard.cardVal(card1, playerHand);
			int second = myCard.cardVal(card2, playerHand);
			/**
			 * adds values to hand and returns sum of hand
			 */
			playerHand = me.sumHand(first, Hand);
			playerHand = me.sumHand(second, Hand);
			/**
			 * prints out string version of hand
			 */
			int dfirst = myCard.cardVal(dealersCard1, dealersHand); //take dealers first card and give it numerical value
			int hiddenVal = myCard.cardVal(hiddenCard, dealersHand);
			dealersHand = myDealer.sumHand(dfirst, dealerHand); //only add showing card to hand
			
			System.out.println("Hand:"+ playerHand + "\n"+ "Card:" +card1 + "\n" + "Card:" + card2 + "\n");
			System.out.println("Dealers Hand:"+ dealersHand  + "\nCard:" + dealersCard1 + "\nCard:" + "[hidden]\n");
			
			if (bet > 0 && chips >= 0) {
				//betting = false;
				hitting = true;
			}else {
				System.out.println("Insufficent Funds");
			}
			while (hitting) {
				Scanner sc = new Scanner(System.in);
				System.out.println("hit or stay");
				String choice = sc.nextLine();
				String nextCardStr;
				int nextCardVal = 0;
				String dealerStr;
				int dealerVal = 0;
				if (!choice.equals("stay")) {
					nextCardStr = myCard.getString(myDeck.deck[(int)(Math.random()*13)]);
					nextCardVal = myCard.cardVal(nextCardStr, playerHand);
					playerHand = me.sumHand(nextCardVal, Hand);
					System.out.println("\nHand:" + playerHand + "\n" + "[added card]\n" + "card:" + nextCardStr );
					if (playerHand > 21) {
						System.out.println("[Over 21]Bust");
						hitting = false;
					}else if (playerHand == 21) {
						System.out.println("Black Jack\nYou Win!");
						hitting = false;
					}
				}
				else if (!choice.equals("hit")) {
					dealersHand = myDealer.sumHand(hiddenVal, dealerHand);
					System.out.println("Dealer:" + dealersHand + "\n" + dealersCard1 + "\n" + hiddenCard );
					hitting = false;
					checking = true;
					while (dealersHand < 17) {
						dealerStr = myCard.getString(myDeck.deck[(int)(Math.random()*13)]);
						dealerVal = myCard.cardVal(dealerStr, dealersHand);
						dealersHand = myDealer.sumHand(dealerVal, dealerHand);
						System.out.println("\nDealer:" + dealersHand + "\n" + "[added card]" + "\n" + "Card:" + dealerStr);
						hitting = false;
						checking = true;
						
					}
					while (checking) {
						if(playerHand > dealersHand || dealersHand > 21) {
							System.out.println("\nYou win");
							chips += (bet * 2);
							checking = false;
						}else if (playerHand < dealersHand || playerHand >= 22) {
							System.out.println("\nyou lose");
							checking = false;
						}else if (playerHand == dealersHand) {
							System.out.println("\nDraw");
							chips += bet;
							checking = false;
						}
						
					}
					
				}
				
			}
			}
			
		}
		
	}

}
