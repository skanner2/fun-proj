
public class Dealer extends Player {

	//ArrayList<Integer> dCards = new ArrayList<Integer>();
	
}
